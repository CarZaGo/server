#/usr/bin/env python2
import os
import sys
import socket

#Codded by CarZaGo
#
def bbsad():
 while 1:
#	 os.system("clear")
	 print "\033[1;39m"
#	 print "-----------------------------------------"
#	 print "        Information gathering tool"
#	 print "        ~~~~~~~~~~~~~~~~~~~~~~~~~~"
#	 print "-----------------------------------------"
	 print " "
	 print "      [\033[1;32m1\033[1;39m] - What is my ip"
	 print "      [\033[1;32m2\033[1;39m] - Port Scan"
	 print "      [\033[1;32m3\033[1;39m] - Whois lookup"
	 print "      [\033[1;32m4\033[1;39m] - GeoIP Lookup"
	 print "      [\033[1;32m5\033[1;39m] - DNS Lookup"
	 print ''
	 print "      {\033[1;32m99\033[1;39m} - back"
	 print ''
	 x = raw_input("\033[1;31m[+] Select >> \033[1;39m ")
	 if x == "1":
		 os.system("clear")
		 print "Your public ip is "
		 print ''
		 os.system("curl http://ipinfo.io/ip")
		 print ""
		 y = raw_input("Press enter to continue ...")
	 elif x == "2":
		 os.system("clear && clear && clear")
		 print "Please Enter your domain name only except http/https"
		 print ''
		 host = raw_input("Enter ip/domain :- ")
		 os.system("rm -rf file.txt")
		 out_file = open("file.txt", "w")
		 out_file.write(host)
		 out_file.close()
		 for hosts in open("file.txt"):
			 n = socket.gethostbyname(hosts)
			 os.system("nmap -u "+n)
			 print ''
			 CarZaGo = raw_input("Press enter to continue ...")
	 elif x == "3":
		 os.system("clear && clear && clear")
		 print "Please Enter your domain name only except http/https"
		 print ''
		 host = raw_input("Enter ip/domain :- ")
		 os.system("curl http://api.hackertarget.com/whois/?q="+host)
		 print ''
		 CarZaGo = raw_input("Press enter to continue ...")
	 elif x == "4":
		 os.system("clear && clear && clear")
		 print "Please Enter your domain name only except http/https"
		 print ''
		 host = raw_input("Enter ip/domain :- ")
		 os.system("curl http://api.hackertarget.com/geoip/?q="+host)
		 print ''
		 CarZaGo = raw_input("Press enter to continue ...")
	 elif x == "5":
		 os.system("clear && clear && clear")
		 print "Please Enter your domain name only except http/https"
		 print ''
		 host = raw_input("Enter ip/domain :- ")
		 os.system("curl http://api.hackertarget.com/dnslookup/?q="+host)
		 print ''
		 CarZaGo = raw_input("Press enter to continue ...")
	 elif x == "99":
		 break
	 else:
		print "[x] Invalid options"
	
