#!/bin/env python2
import urllib2
import sys
import os

def ves():
 file = open("modules/version.txt", "r")
 main = file.read()
 file.close()

 try:
  boothappa = "https://raw.githubusercontent.com/CarZaGo/server1/master/version.txt"
  version = urllib2.urlopen(boothappa).read()

  if main != version:
	  print ''
	  print "New version available"
	  ravi = "/data/data/com.termux/files/home/server.sh"
	  if os.path.exists(ravi):
		print "Run this script again ",ravi
	  else:
		os.system("curl -LO https://raw.githubusercontent.com/CarZaGo/server1/master/server.sh")
		os.system("mv server.sh $HOME")
		print "Run this script again ",ravi
	  print ''
  else:
	  print ''
	  print "No updates available right now ..."
	  print ''
 except urllib2.URLError:
	 print ''
	 print 'Check your internet connection'
	 print ''
