cd /sdcard/Ss
python2 pyserver.py